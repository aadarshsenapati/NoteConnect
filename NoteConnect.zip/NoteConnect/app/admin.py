from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined')
    ordering = ('email',)

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name', 'email')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'first_name', 'last_name', 'password1', 'password2', 'is_staff', 'is_active'),
        }),
    )


from django.contrib import admin
from .models import UploadedFile  # Import your model

@admin.register(UploadedFile)
class UploadedFileAdmin(admin.ModelAdmin):
    list_display = ('title', 'uploaded_by', 'uploaded_at')  # Columns to display in admin
    search_fields = ('title', 'uploaded_by__username')  # Add search functionality
    list_filter = ('uploaded_at',)  # Add filter by date uploaded
    actions = ['delete_selected_files']  # Add bulk delete action

    # Bulk delete action to clean up storage
    def delete_selected_files(self, request, queryset):
        for file in queryset:
            file.file.delete(save=False)  # Delete file from storage
            file.delete()  # Delete the database record
        self.message_user(request, "Selected files and records have been successfully deleted.")

    delete_selected_files.short_description = "Delete selected files (and remove from storage)"
