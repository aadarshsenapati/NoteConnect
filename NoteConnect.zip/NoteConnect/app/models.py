from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.conf import settings


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']


class UploadedFile(models.Model):
    CATEGORY_CHOICES = [
        ('notes', 'Notes'),
        ('pyq', 'Previous Year Questions'),
    ]
    title = models.CharField(max_length=255, db_index=True)
    file = models.FileField(upload_to='uploads/')
    category = models.CharField(max_length=25, choices=CATEGORY_CHOICES, default='pyq')
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    likes = models.PositiveIntegerField(default=0)
    dislikes = models.PositiveIntegerField(default=0)
    liked_by = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='liked_files', blank=True)
    disliked_by = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='disliked_files', blank=True)

    def points(self):
        return (self.likes * 5) - (self.dislikes * 10)

    def like_file(self, user):
        """
        Adds a like to the file by the given user. Removes a dislike if present.
        """
        if user in self.liked_by.all():
            # User already liked the file, do nothing
            return
        if user in self.disliked_by.all():
            # Remove dislike first
            self.disliked_by.remove(user)
            self.dislikes -= 1
        # Add like
        self.liked_by.add(user)
        self.likes += 1
        self.save()

    def dislike_file(self, user):
        """
        Adds a dislike to the file by the given user. Removes a like if present.
        """
        if user in self.disliked_by.all():
            # User already disliked the file, do nothing
            return
        if user in self.liked_by.all():
            # Remove like first
            self.liked_by.remove(user)
            self.likes -= 1
        # Add dislike
        self.disliked_by.add(user)
        self.dislikes += 1
        self.save()

    def __str__(self):
        return f"{self.title} ({self.category})"
    

class Message(models.Model):
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)  # Admin can mark as deleted

    def __str__(self):
        return f"{self.sender}: {self.content[:20]}"