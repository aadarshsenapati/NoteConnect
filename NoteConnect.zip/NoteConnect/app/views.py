from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .forms import create_user_from_form
from .forms import FileUploadForm
from .models import UploadedFile
from django.http import FileResponse, HttpResponse
import os
from django.http import FileResponse, HttpResponse
from django.conf import settings
import os
from urllib.parse import unquote
from django.shortcuts import get_object_or_404
from django.views.decorators.clickjacking import xframe_options_exempt
import mimetypes
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from .utils import generate_otp, send_otp
from .models import CustomUser
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.contrib.auth.tokens import default_token_generator
from django.http import HttpResponse
from .forms import PasswordResetRequestForm
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from .models import Message
import json



otp_storage = {}
def is_admin(user):
    return user.is_staff

def index(request):
    return render(request, "index.html")

def log(request):
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        
        # Authenticate using the custom backend
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)  # Log in the user
            return redirect('/dashboard')  # Redirect to the dashboard
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials.'})

    return render(request, 'login.html')

def sign(request):
    
    if request.method == "POST":
        data = {
            "first_name": request.POST.get("first_name"),
            "last_name": request.POST.get("last_name"),
            "username": request.POST.get("username"),
            "email": request.POST.get("email"),
            "password1": request.POST.get("password1"),
            "password2": request.POST.get("password2"),
        }
        print("Sign view called.")
        user, errors = create_user_from_form(data)

        # Debugging: Print results
        print("Data submitted:", data)
        if errors:
            print("Errors encountered:", errors)
            return render(request, "signup.html", {"errors": errors, "data": data})

        otp = generate_otp()
        otp_storage[user.email] = otp  # Save OTP for verification
        send_otp(user.email, otp)

        # Redirect to login or another page upon success
        return redirect(f"/verify_email?email={user.email}")
    else:
        return render(request, "signup.html")


@login_required
def dashboard_view(request):
    return render(request, "dashboard.html", {"user": request.user})

def log_o(request):
    logout(request)
    return redirect("index")

def notes(request):
    notes_files = UploadedFile.objects.filter(category='notes')
    pdf_url = request.GET.get('pdf_url', None)
    return render(request, "notes.html", {'files': notes_files,'pdf_url': pdf_url})

def upload(request):
    return render(request, "upload.html")

def pyq(request):
    pyq_files = UploadedFile.objects.filter(category='pyq')
    return render(request, "pyq.html",{'files': pyq_files})

def home(request):
    return render(request, "home.html")
def dashboard(request):
    return render(request, "dashboard.html")
@login_required
def upload_file(request):
    if request.method == 'POST':
        print(request.POST)  # Print the entire POST data
        print(request.FILES) 
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.save(commit=False)
            uploaded_file.uploaded_by = request.user  # Save the uploader
            uploaded_file.save()
            return redirect('file_list')  # Redirect to the file list
    else:
        form = FileUploadForm()
    return render(request, 'upload.html', {'form': form})

@login_required
def file_list(request):
    files = UploadedFile.objects.filter(uploaded_by=request.user)
    file_data = [
        {
            "file": file,
            "points": file.points(),
        }
        for file in files
    ]
    return render(request, 'file_list.html', {'files': file_data})


@login_required
def delete_file(request, file_id):
    # Get the file object, ensuring it belongs to the logged-in user
    file_to_delete = get_object_or_404(UploadedFile, id=file_id, uploaded_by=request.user)
    file_to_delete.delete()
    return redirect('file_list')  # Redirect to the file list after deletion


import os
from urllib.parse import unquote
from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.contrib.auth.decorators import login_required

@login_required
@xframe_options_exempt
def view_pdf(request, file_path):
    file_full_path = os.path.join(settings.MEDIA_ROOT, file_path)
    file_url = f"/media/{file_path}"
    file_type, _ = mimetypes.guess_type(file_full_path)

    # Determine the file type
    if file_type == "application/pdf":
        file_type = "pdf"
    elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        file_type = "docx"
    elif file_type and file_type.startswith("image/"):
        file_type = "image"
    else:
        return HttpResponse("Unsupported file type.", status=400)

    return render(request, "viewer.html", {
        "file_type": file_type,
        "file_url": file_url,
    })

from django.http import JsonResponse

def search_notes(request):
    query = request.GET.get('q', '')  
    files = UploadedFile.objects.filter(
        title__icontains=query
    )
    results = [{"title": file.title, "url": file.file.url} for file in files]
    return JsonResponse({"results": results})

def search_pyq(request):
    query = request.GET.get('q', '') 
    files = UploadedFile.objects.filter(
        title__icontains=query
    )
    results = [{"title": file.title, "url": file.file.url} for file in files]
    return JsonResponse({"results": results})


# views.py

def verify_email(request):
    email = request.GET.get("email")
    if request.method == "POST":
        otp = request.POST.get("otp")
        if otp_storage.get(email) == int(otp):  # Check OTP
            user = CustomUser.objects.get(email=email)
            user.is_email_verified = True
            user.save()
            otp_storage.pop(email, None)  # Remove OTP after verification
            return redirect("/log")  # Redirect to login after successful verification
        else:
            return render(request, "verify_email.html", {"error": "Invalid OTP."})
    return render(request, "verify_email.html", {"email": email})


def reset_password_request(request):
    if request.method == "POST":
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data["email"]
            user = User.objects.filter(email=email).first()
            if user:
                # Generate token and send email
                token = default_token_generator.make_token(user)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                reset_link = request.build_absolute_uri(f"/reset_password/{uid}/{token}/")
                send_mail(
                    "Password Reset Request",
                    f"Click the link to reset your password: {reset_link}",
                    "noreply@yourdomain.com",
                    [email],
                )
                return HttpResponse("Password reset email sent. Check your inbox.")
            return HttpResponse("No account found with this email.")
    else:
        form = PasswordResetRequestForm()
    return render(request, "reset_password_request.html", {"form": form})


from django.contrib.auth import get_user_model
from .forms import SetNewPasswordForm
from django.contrib.auth.tokens import default_token_generator

User = get_user_model()

def reset_password_confirm(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user and default_token_generator.check_token(user, token):
        if request.method == "POST":
            form = SetNewPasswordForm(request.POST)
            if form.is_valid():
                new_password = form.cleaned_data["new_password1"]
                user.set_password(new_password)
                user.save()
                return HttpResponse("Password reset successful. You can now log in.")
        else:
            form = SetNewPasswordForm()
        return render(request, "reset_password_confirm.html", {"form": form})
    return HttpResponse("Invalid reset link.")


@login_required
@require_POST
def like_file(request, file_id):
    file = get_object_or_404(UploadedFile, id=file_id)
    file.likes += 1
    file.save()
    return JsonResponse({"likes": file.likes, "points": file.points()})

@login_required
@require_POST
def dislike_file(request, file_id):
    file = get_object_or_404(UploadedFile, id=file_id)
    file.dislikes += 1
    file.save()
    return JsonResponse({"dislikes": file.dislikes, "points": file.points()})

@login_required
def search_dashboard(request):
    query = request.GET.get('q', '').strip()
    if query:
        files = UploadedFile.objects.filter(title__icontains=query)  # Case-insensitive search
        results = [
            {
                'title': file.title,
                'category': file.get_category_display(),
                'url': f"/files/{file.id}/view/"  # Adjust URL pattern based on your routes
            }
            for file in files
        ]
        return JsonResponse({'results': results})
    return JsonResponse({'results': []})


def search_dashboard(request):
    query = request.GET.get('q', '').strip()
    if query:
        files = UploadedFile.objects.filter(title__icontains=query)  # Case-insensitive search
        results = [
            {
                'title': file.title,
                'category': file.get_category_display(),
                'url': f"/files/{file.id}/view/"
            }
            for file in files
        ]
        return JsonResponse({'results': results})
    return JsonResponse({'results': []})


@login_required
def fetch_messages(request):
    messages = Message.objects.filter(is_deleted=False).order_by("-timestamp")
    data = [
        {
            "id": msg.id,
            "sender": msg.sender.username,
            "content": msg.content,
            "timestamp": msg.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        }
        for msg in messages
    ]
    return JsonResponse({"messages": data}, safe=False)

# Send a new message
@csrf_exempt
@login_required
def send_message(request):
    if request.method == "POST":
        data = json.loads(request.body)
        content = data.get("content", "").strip()
        if content:
            Message.objects.create(sender=request.user, content=content)
            return JsonResponse({"success": True})
    return JsonResponse({"success": False}, status=400)

# Delete a message (Admin only)
@csrf_exempt
@login_required
def delete_message(request, message_id):
    if request.user.is_superuser:  # Only admin can delete messages
        try:
            message = Message.objects.get(id=message_id)
            message.is_deleted = True
            message.save()
            return JsonResponse({"success": True})
        except Message.DoesNotExist:
            return JsonResponse({"success": False, "error": "Message not found"}, status=404)
    return JsonResponse({"success": False, "error": "Unauthorized"}, status=403)

@login_required
def chatbox(request):
    return render(request, 'chatbox.html')