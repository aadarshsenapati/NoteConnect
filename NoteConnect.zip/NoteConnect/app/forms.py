from django.contrib.auth import get_user_model

User = get_user_model()
from django import forms
from .models import UploadedFile

def validate_signup_data(data):
    errors = {}

    # Validate first name
    first_name = data.get("first_name")
    if not first_name:
        errors["first_name"] = "First name is required."

    # Validate last name
    last_name = data.get("last_name")
    if not last_name:
        errors["last_name"] = "Last name is required."

    # Validate username
    username = data.get("username")
    if not username:
        errors["username"] = "Username is required."
    elif User.objects.filter(username=username).exists():
        errors["username"] = "Username is already in use."

    # Validate email
    email = data.get("email")
    if not email:
        errors["email"] = "Email is required."
    elif User.objects.filter(email=email).exists():
        errors["email"] = "Email is already in use."

    # Validate passwords
    password1 = data.get("password1")
    password2 = data.get("password2")
    if not password1 or not password2:
        errors["password"] = "Both password fields are required."
    elif password1 != password2:
        errors["password"] = "Passwords do not match."

    return errors


def create_user_from_form(data):
    # Validate the data
    errors = validate_signup_data(data)
    if errors:
        print("Validation failed with errors:", errors)
        return None, errors

    # Create and save the user using the custom user manager
    try:
        user = User.objects.create_user(
            username=data["username"],
            email=data["email"],
            password=data["password1"],  # Password hashing is handled by the manager
            first_name=data["first_name"],
            last_name=data["last_name"],
        )
        print("User successfully created:", user)
        return user, None
    except Exception as e:
        print("Exception while creating user:", e)
        errors["exception"] = str(e)
        return None, errors



class FileUploadForm(forms.ModelForm):
    class Meta:
        model = UploadedFile
        fields = ['title', 'file', 'category']
        widgets = {
            'category': forms.Select(choices=UploadedFile.CATEGORY_CHOICES),
        }


class PasswordResetRequestForm(forms.Form):
    email = forms.EmailField(label="Email", max_length=254, widget=forms.EmailInput(attrs={"autocomplete": "email"}))

class SetNewPasswordForm(forms.Form):
    new_password1 = forms.CharField(label="New Password", widget=forms.PasswordInput)
    new_password2 = forms.CharField(label="Confirm New Password", widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("new_password1")
        password2 = cleaned_data.get("new_password2")

        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned_data
