import random
from django.core.mail import send_mail
from django.conf import settings

def generate_otp():
    """Generates a 4-digit OTP."""
    return random.randint(1000, 9999)

def send_otp(email, otp):
    """Sends OTP to the provided email."""
    subject = "Email Verification - OTP"
    message = f"Your OTP for email verification is: {otp}"
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, from_email, recipient_list)