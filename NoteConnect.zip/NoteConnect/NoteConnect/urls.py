"""
URL configuration for NoteConnect project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from django.contrib import admin
from django.urls import path
from app import views;
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from app.views import fetch_messages, send_message, delete_message

app_name='app'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('log', views.log, name='log'),
    path('home', views.home, name='home'),
    path('sign', views.sign, name='sign'),
    path('verify_email', views.verify_email, name='verify_email'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('notes', views.notes, name='notes'),
    path('log_o', views.log_o, name='log_o'),
    path('upload', views.upload, name='upload'),
    path('pyq', views.pyq, name='pyq'),
    path('upload_file', views.upload_file, name='upload_file'),
    path('files/', views.file_list, name='file_list'),
    path('files/delete/<int:file_id>/', views.delete_file, name='delete_file'),
    path('search_notes/', views.search_notes, name='search_notes'),
    path('search_pyq/', views.search_pyq, name='search_pyq'),
    path("reset_password/", views.reset_password_request, name="reset_password_request"),
    path("reset_password/<uidb64>/<token>/", views.reset_password_confirm, name="reset_password_confirm"),
    path('files/<int:file_id>/like/', views.like_file, name='like_file'),
    path('files/<int:file_id>/dislike/', views.dislike_file, name='dislike_file'),
    path('dashboard/search/', views.search_dashboard, name='search_dashboard'),
    re_path(r'^view_pdf/(?P<file_path>.+)/$', views.view_pdf, name='view_pdf'),
    path('chat/', views.chatbox, name='chatbox'),
    path('fetch-messages/', fetch_messages, name='fetch_messages'),
    path('send-message/', send_message, name='send_message'),
    path('delete-message/<int:message_id>/', delete_message, name='delete_message'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)